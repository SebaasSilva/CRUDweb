
package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {
    Connection cx;
    String bd="programacionweb";
    String url="jdbc:mysql://localhost:3306/"+bd;
    String user="root";
    String pass="";
    
    public Connection conectar(){
        try {
            Class.forName("com.mysql.jdbc.Driver");        
            cx=(Connection)DriverManager.getConnection(url,user,pass);
            System.out.println("Se conecto");
        } catch (ClassNotFoundException|SQLException ex) {
            System.out.println("No se conecto");
        }
        return cx;
    }
    public void desconectar(){
        try {
            cx.close();
            System.out.println("Desconectado");
        } catch (SQLException ex) {
            System.out.println("No se pudo cerrar conexion");
        }
        
    }
    
            
}

