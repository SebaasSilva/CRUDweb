package crud;


import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.Principal;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Controlador implements ActionListener, MouseListener {

    Vista v;
    Usuario p, p1;
    daoUser dao;
    int id = 0;
    ArrayList<Usuario> lista = null;

    public static void main(String[] args) {
        Controlador c = new Controlador();
    }

    public Controlador() {
        v = new Vista();
        dao = new daoUser();
        p1 = new Usuario();
        v.btnAgregar.addActionListener(this);
        v.btnEliminar.addActionListener(this);
        v.btnGuardar.addActionListener(this);
        v.btnLimpiar.addActionListener(this);
        
        v.tblDatos.addMouseListener(this);
        refrescarTabla();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == v.btnAgregar) {//Aqui va el codigo para agregar registro
            p = new Usuario();
            
            p.setUsername(v.txtUsername.getText());
            p.setPassword(v.txtPassword.getText());
            
            if (!dao.create(p)) {
                JOptionPane.showMessageDialog(this.v, "No se inserto registro :c");
            }

            limpiarCampos();
        }
        if (e.getSource() == v.btnEliminar) {//Aqui va el codigo para sliminar registro
            int x = JOptionPane.showConfirmDialog(this.v, "ESTAS SEGURO DE ELIMINAR ESTE RESGITRO?");
            if (x == 0 && id > 0) {
                if (!dao.delete(id)) {
                    JOptionPane.showMessageDialog(this.v, "No elimino registro");
                }
            }
        }
        if (e.getSource() == v.btnGuardar) {//Aqui va el codigo para editar registro
            p1.setUsername(v.txtUsername.getText());
            p1.setPassword(v.txtPassword.getText());
            
            if (!dao.update(p1)) {
                JOptionPane.showMessageDialog(this.v, "No se actualizo registro");
            }
        }
        if (e.getSource() == v.btnLimpiar) {//Aqui va el codigo para limpiar campos
            limpiarCampos();
        }
        
        refrescarTabla();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == v.tblDatos) {//Aqui va el codigo para cuando de clic sobre la tabla
            int fila = v.tblDatos.getSelectedRow();
            id = Integer.parseInt(v.tblDatos.getValueAt(fila, 0).toString());
            p1 = dao.read(id);
            v.txtUsername.setText(p1.getUsername());
            v.txtPassword.setText(p1.getPassword());

        }
    }

    public void refrescarTabla() {
        while (v.model.getRowCount() > 0) {
            v.model.removeRow(0);
        }
        lista = dao.read();
        for (Usuario p : lista) {
            Object item[] = new Object[5];
            item[0] = p.getIduser();
            item[1] = p.getUsername();
            item[2] = p.getPassword();
            v.model.addRow(item);
        }
        v.tblDatos.setModel(v.model);
    }

    public void limpiarCampos() {
        v.txtUsername.setText("");
        v.txtPassword.setText("");

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}
