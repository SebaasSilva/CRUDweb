
package crud;

//CLASE MODELO O CLASE ENTIDAD DE BASE DE DATOS
public class Usuario {
    int id_user;
    String username;
    String password;
    
    
    
    public static void main(String[] args) {
        Usuario p=new  Usuario();
        p.setUsername("Sebastian");
        p.setPassword("123");
        Usuario p2=new Usuario(1,"Sebastian","123");
        Usuario p3=new Usuario(2,"Harold","123");
        System.out.println("p1: "+p.getUsername());
        System.out.println(p.toString());
        System.out.println(p2.toString());
        System.out.println(p3.toString());
    }
    public Usuario(){
    }

    public Usuario(int id_user, String username, String password) {
        this.id_user = id_user;
        this.username = username;
        this.password = password;
        
    }

    public Usuario(String username, String password) {
        this.username = username;
        this.password = password;   
    }
    
    
    public int getIduser() {
        return id_user;
    }

    public void setIduser(int id_user) {
        this.id_user = id_user;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String precio) {
        this.password = password;
    }

    

    @Override
    public String toString() {
        return "Usuario{" + "id_user=" + id_user + ", username=" + username + ", precio=" + password + '}';
    }
    
    
    
    
    
}
