
package crud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import org.netbeans.lib.awtextra.*;

public class Vista extends JFrame{
    JLabel lblId,lblUsername,lblPassword,lblIduser;
    JTextField txtUsername, txtPassword;
    JScrollPane scroll;
    DefaultTableModel model;
    JTable tblDatos;
    JButton btnAgregar,btnEliminar,btnGuardar,btnLimpiar,btnPDF;
    public Vista(){
        this.setTitle("Ejercicio");
        this.setSize(550, 600);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(new AbsoluteLayout());
        
        lblId=new JLabel("ID ");
        this.getContentPane().add(lblId,new AbsoluteConstraints(10,10,100,20));
        lblUsername=new JLabel("Username");
        this.getContentPane().add(lblUsername,new AbsoluteConstraints(10,40,100,20));
        lblPassword=new JLabel("Password");
        this.getContentPane().add(lblPassword,new AbsoluteConstraints(10,70,100,20));
        
        txtUsername=new JTextField();
        this.getContentPane().add(txtUsername,new AbsoluteConstraints(120, 40,100, 20));
        txtPassword=new JTextField();
        this.getContentPane().add(txtPassword,new AbsoluteConstraints(120, 70,100, 20));
        
        
        btnAgregar=new JButton("Agregar");
        this.getContentPane().add(btnAgregar,new AbsoluteConstraints(300, 10,100, 20));
        btnEliminar=new JButton("Eliminar");
        this.getContentPane().add(btnEliminar,new AbsoluteConstraints(300, 40,100, 20));
        btnGuardar=new JButton("Guardar");
        this.getContentPane().add(btnGuardar,new AbsoluteConstraints(300, 70,100, 20));
        btnLimpiar=new JButton("Limpiar");
        this.getContentPane().add(btnLimpiar,new AbsoluteConstraints(300, 100,100, 20));

        
        tblDatos=new JTable();
        scroll=new JScrollPane();
        model=new  DefaultTableModel();
        model.addColumn("Id User");
        model.addColumn("Username");
        model.addColumn("Password");
        tblDatos.setModel(model);
        scroll.setViewportView(tblDatos);
        this.getContentPane().add(scroll,new AbsoluteConstraints(10, 200,500, 300));
        this.setVisible(true);
        
    }
}
