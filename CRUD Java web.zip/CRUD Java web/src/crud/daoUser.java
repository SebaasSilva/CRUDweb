package crud;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class daoUser {

    Conexion c;

    public daoUser() {
        c = new Conexion();
    }

    public boolean create(Usuario p) {
        try {
            String sql = "INSERT INTO users(id_user,username,password,) VALUES(?,?,?)";
            PreparedStatement ps = c.conectar().prepareStatement(sql);
            ps.setInt(1, p.getIduser());
            ps.setString(2, p.getUsername());
            ps.setString(3, p.getPassword());
            ps.execute();
            ps.close();
            ps = null;
            c.desconectar();
            return true;
        } catch (SQLException ex) {
            System.out.println("No se inserto registro :'v");
            return false;
        }

    }

    public ArrayList<Usuario> read() {
        ArrayList<Usuario> lista = new ArrayList<Usuario>();
        try {
            String sql = "SELECT * FROM users";
            PreparedStatement ps = c.conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Usuario p = new Usuario();
                p.setIduser(rs.getInt("id_user"));
                p.setUsername(rs.getString("username"));
                p.setPassword(rs.getString("password"));
                
                lista.add(p);
            }
            ps.close();
            ps = null;
            c.desconectar();
        } catch (SQLException ex) {
            System.out.println("Fallo metodo read");
        }
        return lista;
    }

    public boolean delete(int id) {
        try {
            String sql = "DELETE FROM users WHERE id_user=?";
            PreparedStatement ps = c.conectar().prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            ps.close();
            ps = null;
            c.desconectar();
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    public boolean update(Usuario p) {
        try {
            String sql = "UPDATE users SET username=?,password=? WHERE idproducto=?";
            PreparedStatement ps = c.conectar().prepareStatement(sql);
            ps.setString(1, p.getUsername());
            ps.setString(2, p.getPassword());
            ps.setInt(3, p.getIduser());
            ps.execute();
            ps.close();
            ps=null;
            c.desconectar();
            return true;
        } catch (SQLException ex) {
            return false;
        }        
    }
    public Usuario read(int id) {
       Usuario p=new Usuario();
        try {
            String sql = "SELECT * FROM users WHERE id_user=?";
            PreparedStatement ps = c.conectar().prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                p.setIduser(rs.getInt("id_user"));
                p.setUsername(rs.getString("username"));
                p.setPassword(rs.getString("password"));
            }
            ps.close();
            ps = null;
            c.desconectar();
        } catch (SQLException ex) {
            System.out.println("Fallo metodo read prodcuto");
        }
        return p;
    }

}
